__author__ = 'Ankit Kumar'

import trainDBscript
#import models

trainDBscript.main()

# filename = "C:/Users/Ankit Kumar/Downloads/sortedTrainList.txt"
# filename1 = "C:/Users/Ankit Kumar/Downloads/test1.txt"
# filename2 = "C:/Users/Ankit Kumar/Downloads/test2.txt"
#
# def read():
#     f = open(filename, "r")
#     print filename
#     line = f.read().splitlines()
#     models.checkStationExists(line)
#
#
# read()
